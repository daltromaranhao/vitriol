import { createBrowserRouter } from 'react-router';

// Pages
import LandingPage from './pages/LandingPage';
import SignInPage from './pages/SignInPage';
import SignUpPage from './pages/SignUpPage';
import OnboardingPage from './pages/OnboardingPage';
import DashboardPage from './pages/DashboardPage';
import ProfilePage from './pages/ProfilePage';
import MembersDirectoryPage from './pages/MembersDirectoryPage';
import ConnectionsPage from './pages/ConnectionsPage';
import MessagesPage from './pages/MessagesPage';
import MapPage from './pages/MapPage';
import NotificationsPage from './pages/NotificationsPage';
import SettingsPage from './pages/SettingsPage';
import FeedPage from './pages/FeedPage';
import HelpRequestsPage from './pages/HelpRequestsPage';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: LandingPage,
  },
  {
    path: '/auth/signin',
    Component: SignInPage,
  },
  {
    path: '/auth/signup',
    Component: SignUpPage,
  },
  {
    path: '/onboarding',
    Component: OnboardingPage,
  },
  {
    path: '/dashboard',
    Component: DashboardPage,
  },
  {
    path: '/profile',
    Component: ProfilePage,
  },
  {
    path: '/members',
    Component: MembersDirectoryPage,
  },
  {
    path: '/connections',
    Component: ConnectionsPage,
  },
  {
    path: '/messages',
    Component: MessagesPage,
  },
  {
    path: '/map',
    Component: MapPage,
  },
  {
    path: '/feed',
    Component: FeedPage,
  },
  {
    path: '/help-requests',
    Component: HelpRequestsPage,
  },
  {
    path: '/notifications',
    Component: NotificationsPage,
  },
  {
    path: '/settings',
    Component: SettingsPage,
  },
]);