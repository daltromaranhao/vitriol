import { RouterProvider } from 'react-router';
import { ThemeProvider } from './contexts/ThemeContext';
import { router } from './routes';
import './i18n';

export default function App() {
  return (
    <ThemeProvider>
      <RouterProvider router={router} />
    </ThemeProvider>
  );
}
