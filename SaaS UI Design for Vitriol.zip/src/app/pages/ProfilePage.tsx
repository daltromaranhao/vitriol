import React from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router';
import { MapPin, Briefcase, Calendar, ShieldCheck, MessageSquare, Mail } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Avatar } from '../components/ui/Avatar';
import { Badge } from '../components/ui/Badge';
import { Navbar } from '../components/Navbar';

export default function ProfilePage() {
  const { t } = useTranslation();

  const profileData = {
    name: 'John Smith',
    profession: 'CEO & Entrepreneur',
    location: 'New York, United States',
    memberSince: 'January 2024',
    verified: true,
    connections: 247,
    bio: 'Serial entrepreneur with 15+ years of experience in technology and finance. Passionate about building global partnerships and supporting emerging markets.',
    interests: ['Technology', 'Finance', 'Real Estate', 'Education', 'Healthcare'],
    image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=400',
  };

  const recentConnections = [
    { name: 'Maria Santos', location: 'Lisbon', image: 'https://images.unsplash.com/photo-1762341114803-a797c44649f0?w=200' },
    { name: 'David Chen', location: 'Singapore', image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=200' },
    { name: 'Sophie Martin', location: 'Paris', image: 'https://images.unsplash.com/photo-1650784854945-264d5b0b6b07?w=200' },
    { name: 'Alex Rivera', location: 'Madrid', image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=200' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Profile Card */}
            <Card>
              <CardContent className="p-6">
                <div className="text-center space-y-4">
                  <div className="relative inline-block">
                    <Avatar 
                      src={profileData.image}
                      alt={profileData.name}
                      size="xl"
                      className="w-24 h-24 mx-auto"
                    />
                    {profileData.verified && (
                      <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-accent rounded-full flex items-center justify-center border-2 border-background">
                        <ShieldCheck className="w-5 h-5 text-accent-foreground" />
                      </div>
                    )}
                  </div>
                  
                  <div>
                    <h2 className="text-2xl font-semibold">{profileData.name}</h2>
                    <p className="text-muted-foreground">{profileData.profession}</p>
                  </div>

                  <div className="flex flex-col gap-2 text-sm">
                    <div className="flex items-center justify-center gap-2 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      {profileData.location}
                    </div>
                    <div className="flex items-center justify-center gap-2 text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      {t('profile.member')} {profileData.memberSince}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-border">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-accent">{profileData.connections}</div>
                      <div className="text-sm text-muted-foreground">{t('profile.connections')}</div>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button variant="accent" className="flex-1 gap-2">
                      <MessageSquare className="w-4 h-4" />
                      {t('common.message')}
                    </Button>
                    <Button variant="outline" size="icon">
                      <Mail className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Verification Badge */}
            {profileData.verified && (
              <Card className="border-accent/30 bg-accent/5">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
                      <ShieldCheck className="w-6 h-6 text-accent" />
                    </div>
                    <div>
                      <div className="font-medium">{t('profile.verified')}</div>
                      <div className="text-xs text-muted-foreground">
                        Identity and credentials verified
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Recent Connections */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Connections</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {recentConnections.map((connection, index) => (
                    <div key={index} className="relative group">
                      <Avatar
                        src={connection.image}
                        alt={connection.name}
                        size="md"
                        className="cursor-pointer hover:ring-2 hover:ring-accent transition-all"
                      />
                    </div>
                  ))}
                  <Link to="/connections">
                    <div className="w-10 h-10 rounded-full border-2 border-dashed border-border flex items-center justify-center text-xs text-muted-foreground hover:border-accent transition-colors cursor-pointer">
                      +{profileData.connections - recentConnections.length}
                    </div>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* About Section */}
            <Card>
              <CardHeader>
                <CardTitle>{t('profile.about')}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  {profileData.bio}
                </p>

                <div>
                  <h4 className="font-medium mb-3">{t('profile.profession')}</h4>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Briefcase className="w-4 h-4" />
                    <span>{profileData.profession}</span>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-3">{t('profile.location')}</h4>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <MapPin className="w-4 h-4" />
                    <span>{profileData.location}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Interests */}
            <Card>
              <CardHeader>
                <CardTitle>Interests & Expertise</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {profileData.interests.map((interest, index) => (
                    <Badge key={index} variant="accent">
                      {interest}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex gap-4 pb-4 border-b border-border">
                    <div className="w-2 h-2 rounded-full bg-accent mt-2" />
                    <div>
                      <p className="text-sm">Connected with <span className="font-medium">Maria Santos</span></p>
                      <p className="text-xs text-muted-foreground">2 days ago</p>
                    </div>
                  </div>
                  <div className="flex gap-4 pb-4 border-b border-border">
                    <div className="w-2 h-2 rounded-full bg-accent mt-2" />
                    <div>
                      <p className="text-sm">Updated profile information</p>
                      <p className="text-xs text-muted-foreground">5 days ago</p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="w-2 h-2 rounded-full bg-accent mt-2" />
                    <div>
                      <p className="text-sm">Joined the network</p>
                      <p className="text-xs text-muted-foreground">January 2024</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
