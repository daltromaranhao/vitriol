import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  HeartHandshake, 
  MapPin, 
  Clock, 
  AlertCircle,
  Filter,
  Plus,
  Stethoscope,
  Briefcase,
  Home as HomeIcon,
  Plane,
  User,
  Shield,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { Navbar } from '../components/Navbar';
import { MobileNav } from '../components/MobileNav';
import { Button } from '../components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Input } from '../components/ui/Input';
import { cn } from '../utils/cn';

interface HelpRequest {
  id: string;
  title: string;
  description: string;
  category: 'medical' | 'professional' | 'housing' | 'travel' | 'legal' | 'other';
  urgency: 'low' | 'medium' | 'high' | 'critical';
  status: 'pending' | 'approved' | 'rejected' | 'resolved';
  location: {
    city: string;
    country: string;
    coordinates?: { lat: number; lng: number };
  };
  requester: {
    name: string;
    memberId: string;
    verified: boolean;
  };
  createdAt: Date;
  approvedAt?: Date;
  resolvedAt?: Date;
  responses: number;
}

const mockHelpRequests: HelpRequest[] = [
  {
    id: '1',
    title: 'Urgent: Medical Consultation Needed',
    description: 'Looking for a cardiology specialist recommendation in the area. Experiencing chest discomfort and need urgent consultation.',
    category: 'medical',
    urgency: 'high',
    status: 'approved',
    location: { city: 'São Paulo', country: 'Brazil' },
    requester: { name: 'Alexandre Silva', memberId: 'M-2847', verified: true },
    createdAt: new Date('2026-02-19'),
    approvedAt: new Date('2026-02-19'),
    responses: 12
  },
  {
    id: '2',
    title: 'Business Partner for Tech Startup',
    description: 'Seeking experienced tech entrepreneur for partnership in AI-driven healthcare platform. Looking for someone with VC connections.',
    category: 'professional',
    urgency: 'medium',
    status: 'approved',
    location: { city: 'Paris', country: 'France' },
    requester: { name: 'Marie Dubois', memberId: 'M-5621', verified: true },
    createdAt: new Date('2026-02-18'),
    approvedAt: new Date('2026-02-18'),
    responses: 8
  },
  {
    id: '3',
    title: 'Legal Advice - International Business',
    description: 'Need guidance on international trade regulations between EU and Latin America for import/export business.',
    category: 'legal',
    urgency: 'medium',
    status: 'approved',
    location: { city: 'Madrid', country: 'Spain' },
    requester: { name: 'Carlos Mendez', memberId: 'M-3947', verified: true },
    createdAt: new Date('2026-02-17'),
    approvedAt: new Date('2026-02-18'),
    responses: 15
  },
  {
    id: '4',
    title: 'Emergency Housing Assistance',
    description: 'Family displaced due to emergency situation. Need temporary housing assistance or recommendations for safe accommodation.',
    category: 'housing',
    urgency: 'critical',
    status: 'approved',
    location: { city: 'New York', country: 'USA' },
    requester: { name: 'John Anderson', memberId: 'M-1284', verified: true },
    createdAt: new Date('2026-02-20'),
    approvedAt: new Date('2026-02-20'),
    responses: 23
  },
  {
    id: '5',
    title: 'Travel Assistance - Visa Support',
    description: 'Need guidance and possible sponsorship letter for business visa application to Singapore. Urgent business meeting scheduled.',
    category: 'travel',
    urgency: 'high',
    status: 'approved',
    location: { city: 'Mumbai', country: 'India' },
    requester: { name: 'Raj Patel', memberId: 'M-7823', verified: true },
    createdAt: new Date('2026-02-19'),
    approvedAt: new Date('2026-02-19'),
    responses: 6
  },
  {
    id: '6',
    title: 'Mentorship for Young Entrepreneur',
    description: 'First-time entrepreneur seeking mentorship from experienced business leaders in the sustainable energy sector.',
    category: 'professional',
    urgency: 'low',
    status: 'approved',
    location: { city: 'Berlin', country: 'Germany' },
    requester: { name: 'Anna Schmidt', memberId: 'M-4562', verified: true },
    createdAt: new Date('2026-02-16'),
    approvedAt: new Date('2026-02-17'),
    responses: 19
  }
];

export default function HelpRequestsPage() {
  const { t } = useTranslation();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedUrgency, setSelectedUrgency] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);

  const categories = [
    { value: 'all', label: t('helpRequests.categories.all'), icon: HeartHandshake },
    { value: 'medical', label: t('helpRequests.categories.medical'), icon: Stethoscope },
    { value: 'professional', label: t('helpRequests.categories.professional'), icon: Briefcase },
    { value: 'housing', label: t('helpRequests.categories.housing'), icon: HomeIcon },
    { value: 'travel', label: t('helpRequests.categories.travel'), icon: Plane },
    { value: 'legal', label: t('helpRequests.categories.legal'), icon: Shield },
    { value: 'other', label: t('helpRequests.categories.other'), icon: AlertCircle },
  ];

  const urgencyLevels = [
    { value: 'all', label: 'All Urgency' },
    { value: 'critical', label: 'Critical', color: 'text-red-500' },
    { value: 'high', label: 'High', color: 'text-orange-500' },
    { value: 'medium', label: 'Medium', color: 'text-yellow-500' },
    { value: 'low', label: 'Low', color: 'text-green-500' },
  ];

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'critical': return 'bg-red-500/10 text-red-500 border-red-500/20';
      case 'high': return 'bg-orange-500/10 text-orange-500 border-orange-500/20';
      case 'medium': return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
      case 'low': return 'bg-green-500/10 text-green-500 border-green-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getCategoryIcon = (category: string) => {
    const cat = categories.find(c => c.value === category);
    return cat ? cat.icon : AlertCircle;
  };

  const filteredRequests = mockHelpRequests.filter(request => {
    const matchesCategory = selectedCategory === 'all' || request.category === selectedCategory;
    const matchesUrgency = selectedUrgency === 'all' || request.urgency === selectedUrgency;
    const matchesSearch = searchQuery === '' || 
      request.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.location.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      request.location.country.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesCategory && matchesUrgency && matchesSearch && request.status === 'approved';
  });

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center">
              <HeartHandshake className="w-6 h-6 text-accent" />
            </div>
            <div>
              <h1 className="text-3xl">{t('helpRequests.title')}</h1>
              <p className="text-muted-foreground">{t('helpRequests.subtitle')}</p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-accent">{mockHelpRequests.filter(r => r.status === 'approved').length}</div>
                <div className="text-sm text-muted-foreground">Active Requests</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-accent">156</div>
                <div className="text-sm text-muted-foreground">Resolved This Month</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-accent">89%</div>
                <div className="text-sm text-muted-foreground">Response Rate</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-accent">2.4h</div>
                <div className="text-sm text-muted-foreground">Avg Response Time</div>
              </CardContent>
            </Card>
          </div>

          {/* Create Request Button */}
          <Button 
            variant="accent" 
            size="lg" 
            className="w-full md:w-auto gap-2"
            onClick={() => setShowCreateModal(true)}
          >
            <Plus className="w-5 h-5" />
            {t('helpRequests.createRequest')}
          </Button>
        </div>

        {/* Filters */}
        <div className="mb-6 space-y-4">
          <Input
            placeholder={t('helpRequests.searchPlaceholder')}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="max-w-md"
          />

          {/* Category Filter */}
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => {
              const Icon = cat.icon;
              return (
                <Button
                  key={cat.value}
                  variant={selectedCategory === cat.value ? 'accent' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedCategory(cat.value)}
                  className="gap-2"
                >
                  <Icon className="w-4 h-4" />
                  {cat.label}
                </Button>
              );
            })}
          </div>

          {/* Urgency Filter */}
          <div className="flex flex-wrap gap-2">
            {urgencyLevels.map((level) => (
              <Button
                key={level.value}
                variant={selectedUrgency === level.value ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedUrgency(level.value)}
                className={cn(
                  'gap-2',
                  selectedUrgency === level.value && level.color
                )}
              >
                {level.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Help Requests List */}
        <div className="space-y-4">
          {filteredRequests.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">{t('helpRequests.noRequests')}</p>
              </CardContent>
            </Card>
          ) : (
            filteredRequests.map((request) => {
              const CategoryIcon = getCategoryIcon(request.category);
              return (
                <Card key={request.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row gap-4">
                      {/* Icon */}
                      <div className="flex-shrink-0">
                        <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
                          <CategoryIcon className="w-6 h-6 text-accent" />
                        </div>
                      </div>

                      {/* Content */}
                      <div className="flex-1 space-y-3">
                        <div className="flex flex-wrap items-start justify-between gap-2">
                          <div className="flex-1">
                            <h3 className="text-xl mb-1">{request.title}</h3>
                            <p className="text-muted-foreground">{request.description}</p>
                          </div>
                          <Badge className={cn('border', getUrgencyColor(request.urgency))}>
                            {request.urgency.toUpperCase()}
                          </Badge>
                        </div>

                        {/* Meta Info */}
                        <div className="flex flex-wrap items-center gap-4 text-sm">
                          <div className="flex items-center gap-1.5 text-muted-foreground">
                            <MapPin className="w-4 h-4" />
                            {request.location.city}, {request.location.country}
                          </div>
                          <div className="flex items-center gap-1.5 text-muted-foreground">
                            <Clock className="w-4 h-4" />
                            {request.createdAt.toLocaleDateString()}
                          </div>
                          <div className="flex items-center gap-1.5">
                            <User className="w-4 h-4 text-muted-foreground" />
                            <span className="text-muted-foreground">{request.requester.name}</span>
                            {request.requester.verified && (
                              <CheckCircle className="w-4 h-4 text-accent" />
                            )}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex flex-wrap items-center gap-3 pt-2">
                          <Button variant="accent" size="sm">
                            {t('helpRequests.offerHelp')}
                          </Button>
                          <Button variant="outline" size="sm">
                            {t('helpRequests.viewDetails')}
                          </Button>
                          <span className="text-sm text-muted-foreground">
                            {request.responses} {t('helpRequests.responses')}
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>

        {/* Info Banner */}
        <Card className="mt-8 bg-accent/5 border-accent/20">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <AlertCircle className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-semibold mb-2">{t('helpRequests.info.title')}</h4>
                <p className="text-sm text-muted-foreground">
                  {t('helpRequests.info.description')}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      <MobileNav />
    </div>
  );
}
