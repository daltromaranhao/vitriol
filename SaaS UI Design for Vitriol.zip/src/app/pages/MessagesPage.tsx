import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Search, Send, MoreVertical, Phone, Video } from 'lucide-react';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Avatar } from '../components/ui/Avatar';
import { Navbar } from '../components/Navbar';
import { MobileNav } from '../components/MobileNav';
import { cn } from '../utils/cn';

export default function MessagesPage() {
  const { t } = useTranslation();
  const [selectedChat, setSelectedChat] = useState(0);
  const [message, setMessage] = useState('');

  const conversations = [
    {
      id: 0,
      name: 'Maria Santos',
      lastMessage: 'That sounds great! Let me know when you arrive.',
      time: '2m ago',
      unread: 2,
      online: true,
      image: 'https://images.unsplash.com/photo-1762341114803-a797c44649f0?w=200',
    },
    {
      id: 1,
      name: 'David Chen',
      lastMessage: 'Thanks for the introduction!',
      time: '1h ago',
      unread: 0,
      online: true,
      image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=200',
    },
    {
      id: 2,
      name: 'Sophie Martin',
      lastMessage: 'I reviewed the documents you sent.',
      time: '3h ago',
      unread: 0,
      online: false,
      image: 'https://images.unsplash.com/photo-1650784854945-264d5b0b6b07?w=200',
    },
    {
      id: 3,
      name: 'Alexandre Silva',
      lastMessage: 'Looking forward to our meeting next week.',
      time: '1d ago',
      unread: 0,
      online: false,
      image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=200',
    },
  ];

  const currentMessages = [
    {
      id: 1,
      sender: 'Maria Santos',
      text: 'Hi! I wanted to discuss the partnership opportunity we talked about.',
      time: '10:30 AM',
      isMine: false,
    },
    {
      id: 2,
      sender: 'You',
      text: 'Hi Maria! Yes, I\'d love to hear more about it.',
      time: '10:32 AM',
      isMine: true,
    },
    {
      id: 3,
      sender: 'Maria Santos',
      text: 'Great! I think there\'s a lot of potential for collaboration between our companies.',
      time: '10:33 AM',
      isMine: false,
    },
    {
      id: 4,
      sender: 'You',
      text: 'I agree. Are you available for a call next week?',
      time: '10:35 AM',
      isMine: true,
    },
    {
      id: 5,
      sender: 'Maria Santos',
      text: 'That sounds great! Let me know when you arrive.',
      time: '10:36 AM',
      isMine: false,
    },
  ];

  const handleSendMessage = () => {
    if (message.trim()) {
      // Handle sending message
      setMessage('');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <MobileNav />
      
      <main className="h-[calc(100vh-4rem)] max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="grid lg:grid-cols-12 gap-4 h-full">
          {/* Conversations List */}
          <div className="lg:col-span-4 xl:col-span-3">
            <Card className="h-full flex flex-col">
              <div className="p-4 border-b border-border">
                <h2 className="text-xl font-semibold mb-4">{t('messages.title')}</h2>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder={t('messages.searchMessages')}
                    className="pl-9 h-9"
                  />
                </div>
              </div>
              <div className="flex-1 overflow-y-auto">
                {conversations.map((conv) => (
                  <button
                    key={conv.id}
                    onClick={() => setSelectedChat(conv.id)}
                    className={cn(
                      'w-full p-4 flex items-start gap-3 hover:bg-accent/10 transition-colors border-b border-border',
                      selectedChat === conv.id && 'bg-accent/20'
                    )}
                  >
                    <Avatar
                      src={conv.image}
                      alt={conv.name}
                      size="md"
                      online={conv.online}
                    />
                    <div className="flex-1 text-left overflow-hidden">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-medium text-sm truncate">{conv.name}</h3>
                        <span className="text-xs text-muted-foreground">{conv.time}</span>
                      </div>
                      <p className="text-xs text-muted-foreground truncate">
                        {conv.lastMessage}
                      </p>
                    </div>
                    {conv.unread > 0 && (
                      <div className="w-5 h-5 rounded-full bg-accent flex items-center justify-center">
                        <span className="text-xs text-accent-foreground">{conv.unread}</span>
                      </div>
                    )}
                  </button>
                ))}
              </div>
            </Card>
          </div>

          {/* Chat Area */}
          <div className="lg:col-span-8 xl:col-span-9">
            <Card className="h-full flex flex-col">
              {/* Chat Header */}
              <div className="p-4 border-b border-border flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar
                    src={conversations[selectedChat].image}
                    alt={conversations[selectedChat].name}
                    size="md"
                    online={conversations[selectedChat].online}
                  />
                  <div>
                    <h3 className="font-semibold">{conversations[selectedChat].name}</h3>
                    <p className="text-xs text-muted-foreground">
                      {conversations[selectedChat].online ? t('common.online') : t('common.offline')}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon">
                    <Phone className="w-5 h-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Video className="w-5 h-5" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="w-5 h-5" />
                  </Button>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {currentMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={cn(
                      'flex gap-3',
                      msg.isMine ? 'flex-row-reverse' : 'flex-row'
                    )}
                  >
                    {!msg.isMine && (
                      <Avatar
                        src={conversations[selectedChat].image}
                        alt={msg.sender}
                        size="sm"
                      />
                    )}
                    <div
                      className={cn(
                        'max-w-[70%] space-y-1',
                        msg.isMine && 'items-end'
                      )}
                    >
                      <div
                        className={cn(
                          'rounded-lg px-4 py-2',
                          msg.isMine
                            ? 'bg-accent text-accent-foreground'
                            : 'bg-muted text-foreground'
                        )}
                      >
                        <p className="text-sm">{msg.text}</p>
                      </div>
                      <span className="text-xs text-muted-foreground px-2">
                        {msg.time}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Message Input */}
              <div className="p-4 border-t border-border">
                <div className="flex gap-2">
                  <Input
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder={t('messages.typeMessage')}
                    className="flex-1"
                  />
                  <Button
                    variant="accent"
                    size="icon"
                    onClick={handleSendMessage}
                  >
                    <Send className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}