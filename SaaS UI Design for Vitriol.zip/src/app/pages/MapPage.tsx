import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Search, MapPin, Users, ZoomIn, ZoomOut, Maximize } from 'lucide-react';
import { Card, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Navbar } from '../components/Navbar';
import { MobileNav } from '../components/MobileNav';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export default function MapPage() {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');

  const memberClusters = [
    { city: 'New York', country: 'USA', members: 2847, lat: 40.7128, lng: -74.0060 },
    { city: 'London', country: 'UK', members: 1923, lat: 51.5074, lng: -0.1278 },
    { city: 'São Paulo', country: 'Brazil', members: 1654, lat: -23.5505, lng: -46.6333 },
    { city: 'Singapore', country: 'Singapore', members: 1432, lat: 1.3521, lng: 103.8198 },
    { city: 'Paris', country: 'France', members: 1298, lat: 48.8566, lng: 2.3522 },
    { city: 'Tokyo', country: 'Japan', members: 1187, lat: 35.6762, lng: 139.6503 },
    { city: 'Dubai', country: 'UAE', members: 987, lat: 25.2048, lng: 55.2708 },
    { city: 'Berlin', country: 'Germany', members: 876, lat: 52.5200, lng: 13.4050 },
  ];

  const topCountries = [
    { name: 'United States', members: 12847, flag: '🇺🇸' },
    { name: 'United Kingdom', members: 8932, flag: '🇬🇧' },
    { name: 'Brazil', members: 6543, flag: '🇧🇷' },
    { name: 'France', members: 5421, flag: '🇫🇷' },
    { name: 'Germany', members: 4876, flag: '🇩🇪' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <MobileNav />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl mb-2">{t('map.title')}</h1>
          <p className="text-muted-foreground">
            Explore our global community of professionals
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Map */}
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="p-6">
                {/* Map Controls */}
                <div className="flex items-center gap-2 mb-4">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder={t('map.searchLocation')}
                      className="pl-9"
                    />
                  </div>
                  <Button variant="outline" size="icon">
                    <ZoomIn className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="icon">
                    <ZoomOut className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="icon">
                    <Maximize className="w-4 h-4" />
                  </Button>
                </div>

                {/* Map Placeholder */}
                <div className="relative aspect-[16/10] bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg overflow-hidden">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1713098965471-d324f294a71d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b3JsZCUyMG1hcCUyMGRpZ2l0YWx8ZW58MXx8fHwxNzcxNDc2NzUxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt="World Map"
                    className="w-full h-full object-cover opacity-60"
                  />
                  
                  {/* Map Markers (Simplified visual representation) */}
                  <div className="absolute inset-0">
                    {/* Example clusters */}
                    <div className="absolute top-1/4 left-1/4">
                      <div className="relative group cursor-pointer">
                        <div className="w-12 h-12 rounded-full bg-accent/80 flex items-center justify-center animate-pulse">
                          <span className="text-xs font-bold text-accent-foreground">2.8K</span>
                        </div>
                        <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 bg-card border border-border rounded-lg p-2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-lg z-10">
                          <div className="text-xs font-medium">New York, USA</div>
                          <div className="text-xs text-muted-foreground">2,847 members</div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="absolute top-1/4 right-1/3">
                      <div className="relative group cursor-pointer">
                        <div className="w-10 h-10 rounded-full bg-accent/80 flex items-center justify-center animate-pulse">
                          <span className="text-xs font-bold text-accent-foreground">1.9K</span>
                        </div>
                        <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 bg-card border border-border rounded-lg p-2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-lg z-10">
                          <div className="text-xs font-medium">London, UK</div>
                          <div className="text-xs text-muted-foreground">1,923 members</div>
                        </div>
                      </div>
                    </div>

                    <div className="absolute bottom-1/3 left-1/3">
                      <div className="relative group cursor-pointer">
                        <div className="w-10 h-10 rounded-full bg-accent/80 flex items-center justify-center animate-pulse">
                          <span className="text-xs font-bold text-accent-foreground">1.7K</span>
                        </div>
                        <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 bg-card border border-border rounded-lg p-2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-lg z-10">
                          <div className="text-xs font-medium">São Paulo, Brazil</div>
                          <div className="text-xs text-muted-foreground">1,654 members</div>
                        </div>
                      </div>
                    </div>

                    <div className="absolute top-1/2 right-1/4">
                      <div className="relative group cursor-pointer">
                        <div className="w-10 h-10 rounded-full bg-accent/80 flex items-center justify-center animate-pulse">
                          <span className="text-xs font-bold text-accent-foreground">1.4K</span>
                        </div>
                        <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 bg-card border border-border rounded-lg p-2 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-lg z-10">
                          <div className="text-xs font-medium">Singapore</div>
                          <div className="text-xs text-muted-foreground">1,432 members</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Legend */}
                  <div className="absolute bottom-4 left-4 bg-card/90 backdrop-blur-sm border border-border rounded-lg p-3 space-y-2">
                    <div className="flex items-center gap-2 text-xs">
                      <div className="w-3 h-3 rounded-full bg-accent" />
                      <span className="text-muted-foreground">Member Clusters</span>
                    </div>
                    <div className="text-xs font-medium">{t('map.members')}: 50,234</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Statistics */}
            <Card>
              <CardContent className="p-6 space-y-4">
                <h3 className="font-semibold">Network Statistics</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Total Members</span>
                    <span className="text-lg font-bold text-accent">50,234</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Countries</span>
                    <span className="text-lg font-bold">152</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Cities</span>
                    <span className="text-lg font-bold">847</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Online Now</span>
                    <span className="text-lg font-bold text-green-500">2,847</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Top Countries */}
            <Card>
              <CardContent className="p-6 space-y-4">
                <h3 className="font-semibold">Top Countries</h3>
                <div className="space-y-3">
                  {topCountries.map((country, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{country.flag}</span>
                        <div>
                          <div className="text-sm font-medium">{country.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {country.members.toLocaleString()} {t('map.members').toLowerCase()}
                          </div>
                        </div>
                      </div>
                      <Badge variant="default">{index + 1}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Major Cities */}
            <Card>
              <CardContent className="p-6 space-y-4">
                <h3 className="font-semibold">Major Hubs</h3>
                <div className="space-y-3">
                  {memberClusters.slice(0, 5).map((cluster, index) => (
                    <button
                      key={index}
                      className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-accent/10 transition-colors text-left"
                    >
                      <div className="flex items-center gap-3">
                        <MapPin className="w-4 h-4 text-accent" />
                        <div>
                          <div className="text-sm font-medium">{cluster.city}</div>
                          <div className="text-xs text-muted-foreground">{cluster.country}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Users className="w-3 h-3 text-muted-foreground" />
                        <span className="text-xs font-medium">{cluster.members}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}