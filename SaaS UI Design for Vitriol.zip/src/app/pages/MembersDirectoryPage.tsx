import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Search, Filter, MapPin, Briefcase } from 'lucide-react';
import { Card, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Avatar } from '../components/ui/Avatar';
import { Badge } from '../components/ui/Badge';
import { Navbar } from '../components/Navbar';
import { MobileNav } from '../components/MobileNav';

export default function MembersDirectoryPage() {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');

  const members = [
    {
      name: 'Maria Santos',
      profession: 'Investment Director',
      location: 'Lisbon, Portugal',
      image: 'https://images.unsplash.com/photo-1762341114803-a797c44649f0?w=400',
      verified: true,
      interests: ['Finance', 'Real Estate'],
    },
    {
      name: 'David Chen',
      profession: 'Tech Entrepreneur',
      location: 'Singapore',
      image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=400',
      verified: true,
      interests: ['Technology', 'Healthcare'],
    },
    {
      name: 'Sophie Martin',
      profession: 'Legal Counsel',
      location: 'Paris, France',
      image: 'https://images.unsplash.com/photo-1650784854945-264d5b0b6b07?w=400',
      verified: true,
      interests: ['Legal', 'Consulting'],
    },
    {
      name: 'Alexandre Silva',
      profession: 'CEO, Tech Solutions',
      location: 'São Paulo, Brazil',
      image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=400',
      verified: true,
      interests: ['Technology', 'Manufacturing'],
    },
    {
      name: 'Emma Johnson',
      profession: 'Marketing Director',
      location: 'London, United Kingdom',
      image: 'https://images.unsplash.com/photo-1762341114803-a797c44649f0?w=400',
      verified: true,
      interests: ['Marketing', 'Education'],
    },
    {
      name: 'Carlos Mendez',
      profession: 'Entrepreneur',
      location: 'Madrid, Spain',
      image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=400',
      verified: true,
      interests: ['Real Estate', 'Architecture'],
    },
    {
      name: 'Yuki Tanaka',
      profession: 'Financial Advisor',
      location: 'Tokyo, Japan',
      image: 'https://images.unsplash.com/photo-1650784854945-264d5b0b6b07?w=400',
      verified: true,
      interests: ['Finance', 'Consulting'],
    },
    {
      name: 'Michael Schmidt',
      profession: 'Innovation Director',
      location: 'Berlin, Germany',
      image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=400',
      verified: false,
      interests: ['Technology', 'Healthcare'],
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <MobileNav />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl mb-2">{t('directory.title')}</h1>
          <p className="text-muted-foreground">
            Discover and connect with verified professionals worldwide
          </p>
        </div>

        {/* Search and Filters */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t('directory.searchPlaceholder')}
                  className="pl-10"
                />
              </div>
              <div className="flex gap-2">
                <Button variant="outline" className="gap-2">
                  <Filter className="w-4 h-4" />
                  {t('common.filter')}
                </Button>
                <select className="px-4 rounded-lg border border-border bg-card text-sm focus:outline-none focus:ring-2 focus:ring-ring">
                  <option>{t('directory.sortBy')}</option>
                  <option>{t('directory.relevance')}</option>
                  <option>{t('directory.newest')}</option>
                  <option>{t('directory.name')}</option>
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Members Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {members.map((member, index) => (
            <Card key={index} className="hover:shadow-lg transition-all group">
              <CardContent className="p-6 space-y-4">
                <div className="flex flex-col items-center text-center">
                  <Avatar
                    src={member.image}
                    alt={member.name}
                    size="xl"
                    className="mb-3"
                  />
                  
                  <div className="space-y-1 mb-3">
                    <div className="flex items-center justify-center gap-2">
                      <h3 className="font-semibold">{member.name}</h3>
                      {member.verified && (
                        <Badge variant="success" className="text-xs">
                          ✓
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{member.profession}</p>
                    <div className="flex items-center justify-center gap-1 text-xs text-accent">
                      <MapPin className="w-3 h-3" />
                      {member.location}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1 justify-center mb-4">
                    {member.interests.map((interest, idx) => (
                      <Badge key={idx} variant="default" className="text-xs">
                        {interest}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex gap-2 w-full">
                    <Button variant="accent" size="sm" className="flex-1">
                      {t('common.connect')}
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      {t('common.viewProfile')}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-8">
          <Button variant="outline" size="lg">
            Load More Members
          </Button>
        </div>
      </main>
    </div>
  );
}