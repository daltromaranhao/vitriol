import React from 'react';
import { useTranslation } from 'react-i18next';
import { User, Globe, Palette, Bell, Lock, Shield, Mail, Eye } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Navbar } from '../components/Navbar';
import { MobileNav } from '../components/MobileNav';
import { useTheme } from '../contexts/ThemeContext';
import { cn } from '../utils/cn';

export default function SettingsPage() {
  const { t, i18n } = useTranslation();
  const { theme, setTheme } = useTheme();

  const languages = [
    { code: 'en', label: 'English', flag: '🇬🇧' },
    { code: 'pt', label: 'Português', flag: '🇧🇷' },
    { code: 'es', label: 'Español', flag: '🇪🇸' },
    { code: 'fr', label: 'Français', flag: '🇫🇷' },
  ];

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
    localStorage.setItem('language', lng);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <MobileNav />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl mb-2">{t('settings.title')}</h1>
          <p className="text-muted-foreground">
            Manage your account preferences and settings
          </p>
        </div>

        <div className="space-y-6">
          {/* Profile Settings */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                  <User className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <CardTitle>{t('settings.profile')}</CardTitle>
                  <CardDescription>Update your personal information</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm mb-2 block">First Name</label>
                  <Input defaultValue="John" />
                </div>
                <div>
                  <label className="text-sm mb-2 block">Last Name</label>
                  <Input defaultValue="Smith" />
                </div>
              </div>
              <div>
                <label className="text-sm mb-2 block">Email</label>
                <Input type="email" defaultValue="john.smith@example.com" />
              </div>
              <div>
                <label className="text-sm mb-2 block">Profession</label>
                <Input defaultValue="CEO & Entrepreneur" />
              </div>
              <Button variant="accent">{t('common.save')}</Button>
            </CardContent>
          </Card>

          {/* Language Settings */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Globe className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <CardTitle>{t('settings.language')}</CardTitle>
                  <CardDescription>Choose your preferred language</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => changeLanguage(lang.code)}
                    className={cn(
                      'flex items-center gap-3 p-4 rounded-lg border transition-all',
                      i18n.language === lang.code
                        ? 'border-accent bg-accent/10'
                        : 'border-border hover:border-accent/50'
                    )}
                  >
                    <span className="text-2xl">{lang.flag}</span>
                    <span className="font-medium">{lang.label}</span>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Theme Settings */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Palette className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <CardTitle>{t('settings.theme')}</CardTitle>
                  <CardDescription>Select your visual theme preference</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setTheme('dark')}
                  className={cn(
                    'p-6 rounded-lg border transition-all',
                    theme === 'dark'
                      ? 'border-accent bg-accent/10'
                      : 'border-border hover:border-accent/50'
                  )}
                >
                  <div className="mb-3 h-20 rounded-lg bg-gradient-to-br from-gray-900 to-gray-800" />
                  <div className="font-medium">{t('settings.darkMode')}</div>
                  <div className="text-xs text-muted-foreground">Premium Dark</div>
                </button>
                <button
                  onClick={() => setTheme('light')}
                  className={cn(
                    'p-6 rounded-lg border transition-all',
                    theme === 'light'
                      ? 'border-accent bg-accent/10'
                      : 'border-border hover:border-accent/50'
                  )}
                >
                  <div className="mb-3 h-20 rounded-lg bg-gradient-to-br from-blue-50 to-white border" />
                  <div className="font-medium">{t('settings.lightMode')}</div>
                  <div className="text-xs text-muted-foreground">Clean Light</div>
                </button>
              </div>
            </CardContent>
          </Card>

          {/* Notifications */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Bell className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <CardTitle>{t('settings.notifications')}</CardTitle>
                  <CardDescription>Manage notification preferences</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Connection Requests</div>
                  <div className="text-sm text-muted-foreground">
                    Get notified when someone wants to connect
                  </div>
                </div>
                <input type="checkbox" defaultChecked className="w-5 h-5" />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Messages</div>
                  <div className="text-sm text-muted-foreground">
                    Receive notifications for new messages
                  </div>
                </div>
                <input type="checkbox" defaultChecked className="w-5 h-5" />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Activity Updates</div>
                  <div className="text-sm text-muted-foreground">
                    Stay updated on network activity
                  </div>
                </div>
                <input type="checkbox" className="w-5 h-5" />
              </div>
            </CardContent>
          </Card>

          {/* Privacy Settings */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Eye className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <CardTitle>{t('settings.privacy')}</CardTitle>
                  <CardDescription>Control who can see your information</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm mb-2 block">Profile Visibility</label>
                <select className="w-full px-4 py-2 rounded-lg border border-border bg-card focus:outline-none focus:ring-2 focus:ring-ring">
                  <option>All Members</option>
                  <option>Connections Only</option>
                  <option>Private</option>
                </select>
              </div>
              <div>
                <label className="text-sm mb-2 block">Connection List Visibility</label>
                <select className="w-full px-4 py-2 rounded-lg border border-border bg-card focus:outline-none focus:ring-2 focus:ring-ring">
                  <option>All Members</option>
                  <option>Connections Only</option>
                  <option>Only Me</option>
                </select>
              </div>
            </CardContent>
          </Card>

          {/* Security */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center">
                  <Lock className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <CardTitle>{t('settings.security')}</CardTitle>
                  <CardDescription>Manage your password and security options</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button variant="outline" className="w-full justify-start gap-2">
                <Lock className="w-4 h-4" />
                Change Password
              </Button>
              <Button variant="outline" className="w-full justify-start gap-2">
                <Shield className="w-4 h-4" />
                Enable Two-Factor Authentication
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}