import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ThumbsUp, MessageCircle, Share2, MoreHorizontal, Image as ImageIcon } from 'lucide-react';
import { Card, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Avatar } from '../components/ui/Avatar';
import { Badge } from '../components/ui/Badge';
import { Navbar } from '../components/Navbar';

export default function FeedPage() {
  const { t } = useTranslation();
  const [postContent, setPostContent] = useState('');

  const posts = [
    {
      id: 1,
      author: 'Maria Santos',
      profession: 'Investment Director',
      location: 'Lisbon, Portugal',
      image: 'https://images.unsplash.com/photo-1762341114803-a797c44649f0?w=400',
      time: '2 hours ago',
      content: 'Excited to announce that our firm has just completed a successful partnership with emerging markets in Southeast Asia. Looking forward to new opportunities! 🌏',
      likes: 47,
      comments: 12,
      shares: 5,
      verified: true,
    },
    {
      id: 2,
      author: 'David Chen',
      profession: 'Tech Entrepreneur',
      location: 'Singapore',
      image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=400',
      time: '5 hours ago',
      content: 'Just returned from the Global Innovation Summit. Amazing to see how technology is connecting professionals worldwide. The future of networking is here.',
      likes: 93,
      comments: 28,
      shares: 15,
      verified: true,
    },
    {
      id: 3,
      author: 'Sophie Martin',
      profession: 'Legal Counsel',
      location: 'Paris, France',
      image: 'https://images.unsplash.com/photo-1650784854945-264d5b0b6b07?w=400',
      time: '1 day ago',
      content: 'Proud to share insights from our latest legal framework for international partnerships. Feel free to connect if you are interested in cross-border business law.',
      likes: 56,
      comments: 19,
      shares: 8,
      verified: true,
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl mb-2">{t('feed.title')}</h1>
          <p className="text-muted-foreground">
            Share updates and connect with your network
          </p>
        </div>

        {/* Post Composer */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex gap-4">
              <Avatar size="md" fallback="JS" />
              <div className="flex-1">
                <textarea
                  value={postContent}
                  onChange={(e) => setPostContent(e.target.value)}
                  placeholder={t('feed.whatsOnMind')}
                  className="w-full min-h-24 rounded-lg border border-border bg-input-background px-4 py-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring resize-none"
                />
                <div className="flex items-center justify-between mt-4">
                  <Button variant="ghost" size="sm" className="gap-2">
                    <ImageIcon className="w-4 h-4" />
                    Add Image
                  </Button>
                  <Button variant="accent" size="sm">
                    {t('feed.post')}
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Feed Posts */}
        <div className="space-y-6">
          {posts.map((post) => (
            <Card key={post.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                {/* Post Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex gap-3">
                    <Avatar src={post.image} alt={post.author} size="md" />
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold">{post.author}</h3>
                        {post.verified && (
                          <Badge variant="success" className="text-xs">✓</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{post.profession}</p>
                      <p className="text-xs text-accent">{post.location}</p>
                      <p className="text-xs text-muted-foreground mt-1">{post.time}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="w-5 h-5" />
                  </Button>
                </div>

                {/* Post Content */}
                <p className="text-sm mb-4 leading-relaxed">{post.content}</p>

                {/* Post Stats */}
                <div className="flex items-center gap-4 py-3 border-y border-border text-sm text-muted-foreground">
                  <span>{post.likes} likes</span>
                  <span>{post.comments} comments</span>
                  <span>{post.shares} shares</span>
                </div>

                {/* Post Actions */}
                <div className="flex items-center gap-2 pt-3">
                  <Button variant="ghost" size="sm" className="flex-1 gap-2">
                    <ThumbsUp className="w-4 h-4" />
                    {t('feed.like')}
                  </Button>
                  <Button variant="ghost" size="sm" className="flex-1 gap-2">
                    <MessageCircle className="w-4 h-4" />
                    {t('feed.comment')}
                  </Button>
                  <Button variant="ghost" size="sm" className="flex-1 gap-2">
                    <Share2 className="w-4 h-4" />
                    {t('feed.share')}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-8">
          <Button variant="outline">
            Load More Posts
          </Button>
        </div>
      </main>
    </div>
  );
}