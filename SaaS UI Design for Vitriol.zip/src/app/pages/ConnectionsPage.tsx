import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { UserPlus, UserCheck, UserX, Users } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Avatar } from '../components/ui/Avatar';
import { Badge } from '../components/ui/Badge';
import { Navbar } from '../components/Navbar';
import { MobileNav } from '../components/MobileNav';
import { cn } from '../utils/cn';

export default function ConnectionsPage() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState<'connections' | 'requests' | 'suggestions'>('connections');

  const myConnections = [
    {
      name: 'Maria Santos',
      profession: 'Investment Director',
      location: 'Lisbon, Portugal',
      image: 'https://images.unsplash.com/photo-1762341114803-a797c44649f0?w=400',
      connectedDate: '2 months ago',
    },
    {
      name: 'David Chen',
      profession: 'Tech Entrepreneur',
      location: 'Singapore',
      image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=400',
      connectedDate: '3 months ago',
    },
    {
      name: 'Sophie Martin',
      profession: 'Legal Counsel',
      location: 'Paris, France',
      image: 'https://images.unsplash.com/photo-1650784854945-264d5b0b6b07?w=400',
      connectedDate: '1 month ago',
    },
  ];

  const connectionRequests = [
    {
      name: 'Alex Rivera',
      profession: 'Marketing Director',
      location: 'Madrid, Spain',
      image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=400',
      mutualConnections: 8,
    },
    {
      name: 'Yuki Tanaka',
      profession: 'Financial Advisor',
      location: 'Tokyo, Japan',
      image: 'https://images.unsplash.com/photo-1650784854945-264d5b0b6b07?w=400',
      mutualConnections: 5,
    },
  ];

  const suggestions = [
    {
      name: 'Michael Schmidt',
      profession: 'Innovation Director',
      location: 'Berlin, Germany',
      image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=400',
      mutualConnections: 15,
      reason: 'Works in Technology',
    },
    {
      name: 'Emma Johnson',
      profession: 'Marketing Director',
      location: 'London, UK',
      image: 'https://images.unsplash.com/photo-1762341114803-a797c44649f0?w=400',
      mutualConnections: 12,
      reason: 'Based in Europe',
    },
    {
      name: 'Carlos Mendez',
      profession: 'Entrepreneur',
      location: 'Madrid, Spain',
      image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=400',
      mutualConnections: 10,
      reason: 'Similar interests',
    },
  ];

  const tabs = [
    { id: 'connections', label: t('connections.myConnections'), icon: Users, count: myConnections.length },
    { id: 'requests', label: t('connections.requests'), icon: UserCheck, count: connectionRequests.length },
    { id: 'suggestions', label: t('connections.suggestions'), icon: UserPlus, count: suggestions.length },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <MobileNav />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl mb-2">{t('connections.title')}</h1>
          <p className="text-muted-foreground">
            Manage your professional network
          </p>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 border-b border-border overflow-x-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={cn(
                  'flex items-center gap-2 px-6 py-3 border-b-2 transition-colors whitespace-nowrap',
                  activeTab === tab.id
                    ? 'border-accent text-accent'
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                )}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
                {tab.count > 0 && (
                  <Badge variant="default" className="ml-1">
                    {tab.count}
                  </Badge>
                )}
              </button>
            );
          })}
        </div>

        {/* My Connections */}
        {activeTab === 'connections' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myConnections.map((connection, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Avatar
                      src={connection.image}
                      alt={connection.name}
                      size="lg"
                    />
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold truncate">{connection.name}</h3>
                      <p className="text-sm text-muted-foreground truncate">
                        {connection.profession}
                      </p>
                      <p className="text-xs text-accent truncate">{connection.location}</p>
                      <p className="text-xs text-muted-foreground mt-2">
                        Connected {connection.connectedDate}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button variant="outline" size="sm" className="flex-1">
                      {t('common.message')}
                    </Button>
                    <Button variant="ghost" size="sm" className="flex-1">
                      {t('common.viewProfile')}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Connection Requests */}
        {activeTab === 'requests' && (
          <div className="space-y-4">
            {connectionRequests.map((request, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                    <Avatar
                      src={request.image}
                      alt={request.name}
                      size="lg"
                    />
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold">{request.name}</h3>
                      <p className="text-sm text-muted-foreground">{request.profession}</p>
                      <p className="text-xs text-accent">{request.location}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {request.mutualConnections} mutual connections
                      </p>
                    </div>
                    <div className="flex gap-2 sm:flex-shrink-0">
                      <Button variant="accent" size="sm" className="gap-2">
                        <UserCheck className="w-4 h-4" />
                        {t('connections.accept')}
                      </Button>
                      <Button variant="outline" size="sm" className="gap-2">
                        <UserX className="w-4 h-4" />
                        {t('connections.decline')}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Suggestions */}
        {activeTab === 'suggestions' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {suggestions.map((suggestion, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center">
                    <Avatar
                      src={suggestion.image}
                      alt={suggestion.name}
                      size="xl"
                      className="mb-4"
                    />
                    <h3 className="font-semibold mb-1">{suggestion.name}</h3>
                    <p className="text-sm text-muted-foreground mb-1">
                      {suggestion.profession}
                    </p>
                    <p className="text-xs text-accent mb-3">{suggestion.location}</p>
                    <div className="flex flex-col gap-2 text-xs text-muted-foreground mb-4">
                      <div>{suggestion.mutualConnections} mutual connections</div>
                      <Badge variant="default">{suggestion.reason}</Badge>
                    </div>
                    <Button variant="accent" size="sm" className="w-full gap-2">
                      <UserPlus className="w-4 h-4" />
                      {t('common.connect')}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}