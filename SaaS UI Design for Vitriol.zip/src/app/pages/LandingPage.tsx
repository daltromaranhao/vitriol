import React from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router';
import { Globe, ShieldCheck, Briefcase, Lock, ArrowRight, CheckCircle, HeartHandshake } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';
import { Navbar } from '../components/Navbar';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { VitriolLogo } from '../components/VitriolLogo';

export default function LandingPage() {
  const { t } = useTranslation();

  const features = [
    {
      icon: Globe,
      title: t('landing.features.global.title'),
      description: t('landing.features.global.description'),
    },
    {
      icon: ShieldCheck,
      title: t('landing.features.verified.title'),
      description: t('landing.features.verified.description'),
    },
    {
      icon: Briefcase,
      title: t('landing.features.professional.title'),
      description: t('landing.features.professional.description'),
    },
    {
      icon: Lock,
      title: t('landing.features.private.title'),
      description: t('landing.features.private.description'),
    },
  ];

  const testimonials = [
    {
      name: 'Alexandre Silva',
      role: 'CEO, Tech Solutions',
      location: 'São Paulo, Brazil',
      content: 'This network has opened doors to partnerships I never imagined possible.',
    },
    {
      name: 'Marie Dubois',
      role: 'Investment Director',
      location: 'Paris, France',
      content: 'The quality of connections and trust level here is unmatched.',
    },
    {
      name: 'Carlos Mendez',
      role: 'Entrepreneur',
      location: 'Madrid, Spain',
      content: 'A truly global community of professionals who understand collaboration.',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar showFull={false} />

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-accent/10" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-5xl lg:text-6xl tracking-tight">
                  {t('landing.hero.title')}
                </h1>
                <p className="text-xl text-accent">{t('landing.hero.subtitle')}</p>
                <p className="text-lg text-muted-foreground max-w-xl">
                  {t('landing.hero.tagline')}
                </p>
              </div>
              <div className="flex flex-wrap gap-4">
                <Link to="/auth/signup">
                  <Button variant="accent" size="lg" className="gap-2">
                    {t('landing.hero.cta')}
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                </Link>
                <Link to="/auth/signin">
                  <Button variant="outline" size="lg">
                    {t('landing.hero.login')}
                  </Button>
                </Link>
              </div>
              <div className="flex items-center gap-8 pt-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-accent">150+</div>
                  <div className="text-sm text-muted-foreground">Countries</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-accent">50K+</div>
                  <div className="text-sm text-muted-foreground">Members</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-accent">98%</div>
                  <div className="text-sm text-muted-foreground">Verified</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-tr from-accent/20 to-primary/20 rounded-2xl blur-3xl" />
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1762340274849-87b569b2f0c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnbG9iYWwlMjBidXNpbmVzcyUyMG5ldHdvcmslMjBjb25uZWN0aW9uc3xlbnwxfHx8fDE3NzE1OTM1NjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Global Network"
                className="relative rounded-2xl shadow-2xl w-full"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl mb-4">{t('landing.features.title')}</h2>
            <p className="text-lg text-muted-foreground">
              {t('landing.features.subtitle')}</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
                  <CardContent className="p-0 space-y-4">
                    <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
                      <Icon className="w-6 h-6 text-accent" />
                    </div>
                    <h3 className="text-xl">{feature.title}</h3>
                    <p className="text-muted-foreground">{feature.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Global Help Network Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 text-accent">
                <HeartHandshake className="w-5 h-5" />
                <span className="font-medium">Global Help Network</span>
              </div>
              <h2 className="text-4xl">Brotherhood in Action</h2>
              <p className="text-lg text-muted-foreground">
                More than just networking—Vitriol is a global support system. When members face challenges, whether medical emergencies, professional needs, or urgent situations, the brotherhood responds.
              </p>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-red-500/10 flex items-center justify-center flex-shrink-0">
                    <HeartHandshake className="w-5 h-5 text-red-500" />
                  </div>
                  <div>
                    <div className="font-medium">Medical Support</div>
                    <div className="text-sm text-muted-foreground">
                      Connect with healthcare professionals and get recommendations in any region
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                    <Briefcase className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <div className="font-medium">Professional Assistance</div>
                    <div className="text-sm text-muted-foreground">
                      Access expertise, mentorship, and business support from members worldwide
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center flex-shrink-0">
                    <Globe className="w-5 h-5 text-green-500" />
                  </div>
                  <div>
                    <div className="font-medium">Global Response</div>
                    <div className="text-sm text-muted-foreground">
                      Members in 150+ countries ready to assist in emergencies and urgent situations
                    </div>
                  </div>
                </div>
              </div>
              <div className="pt-4">
                <div className="flex items-center gap-6">
                  <div>
                    <div className="text-2xl font-bold text-accent">24/7</div>
                    <div className="text-sm text-muted-foreground">Global Coverage</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-accent">2.4h</div>
                    <div className="text-sm text-muted-foreground">Avg Response</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-accent">156</div>
                    <div className="text-sm text-muted-foreground">Helped/Month</div>
                  </div>
                </div>
              </div>
            </div>
            <Card className="p-8 bg-gradient-to-br from-accent/5 to-primary/5 border-accent/20">
              <CardContent className="p-0 space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-xl bg-accent/20 flex items-center justify-center">
                    <HeartHandshake className="w-8 h-8 text-accent" />
                  </div>
                  <div>
                    <h3 className="text-2xl">Help Requests</h3>
                    <p className="text-muted-foreground">Verified, reviewed, and secure</p>
                  </div>
                </div>
                <p className="text-muted-foreground">
                  Our Help Request system allows members to seek assistance in critical situations. Every request is reviewed by administrators to ensure authenticity and prevent abuse.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-card">
                    <div className="text-lg font-bold text-accent">Medical</div>
                    <div className="text-sm text-muted-foreground">Healthcare support</div>
                  </div>
                  <div className="p-4 rounded-lg bg-card">
                    <div className="text-lg font-bold text-accent">Professional</div>
                    <div className="text-sm text-muted-foreground">Business assistance</div>
                  </div>
                  <div className="p-4 rounded-lg bg-card">
                    <div className="text-lg font-bold text-accent">Legal</div>
                    <div className="text-sm text-muted-foreground">Legal guidance</div>
                  </div>
                  <div className="p-4 rounded-lg bg-card">
                    <div className="text-lg font-bold text-accent">Travel</div>
                    <div className="text-sm text-muted-foreground">Travel support</div>
                  </div>
                </div>
                <Link to="/auth/signup">
                  <Button variant="accent" className="w-full gap-2">
                    Join to Access Help Network
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Visual Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1758691737158-18ffa31c0a46?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBkaXZlcnNlJTIwdGVhbSUyMG1lZXRpbmd8ZW58MXx8fHwxNzcxNTU3NDg2fDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Professional Network"
                className="rounded-2xl shadow-xl w-full"
              />
            </div>
            <div className="order-1 lg:order-2 space-y-6">
              <h2 className="text-4xl">Built for Global Professionals</h2>
              <p className="text-lg text-muted-foreground">
                Connect with verified leaders, entrepreneurs, and professionals across industries and continents.
              </p>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <div className="font-medium">Verified Identity</div>
                    <div className="text-sm text-muted-foreground">
                      All members undergo thorough verification
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <div className="font-medium">Private & Secure</div>
                    <div className="text-sm text-muted-foreground">
                      Your data and connections remain confidential
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                  <div>
                    <div className="font-medium">Quality Connections</div>
                    <div className="text-sm text-muted-foreground">
                      Build meaningful relationships with trusted professionals
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl mb-4">{t('landing.testimonials.title')}</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="p-6">
                <CardContent className="p-0 space-y-4">
                  <p className="text-muted-foreground italic">"{testimonial.content}"</p>
                  <div>
                    <div className="font-medium">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                    <div className="text-sm text-accent">{testimonial.location}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="rounded-2xl bg-gradient-to-br from-primary via-primary/90 to-accent p-12 space-y-6">
            <h2 className="text-4xl text-primary-foreground">{t('landing.cta.title')}</h2>
            <p className="text-lg text-primary-foreground/90">
              {t('landing.cta.description')}
            </p>
            <Link to="/auth/signup">
              <Button variant="accent" size="lg" className="gap-2">
                {t('landing.cta.button')}
                <ArrowRight className="w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <VitriolLogo size={32} className="text-accent" />
              <div>
                <div className="font-semibold">Vitriol</div>
                <div className="text-xs text-muted-foreground">Global Brotherhood</div>
              </div>
            </div>
            <div className="text-sm text-muted-foreground">
              © 2026 Vitriol. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}