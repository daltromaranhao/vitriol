import React from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router';
import { TrendingUp, Users, Map, MessageSquare, UserPlus, HeartHandshake, MapPin, Clock, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Avatar } from '../components/ui/Avatar';
import { Badge } from '../components/ui/Badge';
import { Navbar } from '../components/Navbar';
import { MobileNav } from '../components/MobileNav';
import { cn } from '../utils/cn';

export default function DashboardPage() {
  const { t } = useTranslation();

  const urgentHelpRequests = [
    {
      id: '1',
      title: 'Urgent: Medical Consultation Needed',
      category: 'medical',
      urgency: 'high',
      location: { city: 'São Paulo', country: 'Brazil' },
      time: '2h ago',
    },
    {
      id: '4',
      title: 'Emergency Housing Assistance',
      category: 'housing',
      urgency: 'critical',
      location: { city: 'New York', country: 'USA' },
      time: '4h ago',
    },
    {
      id: '5',
      title: 'Travel Assistance - Visa Support',
      category: 'travel',
      urgency: 'high',
      location: { city: 'Mumbai', country: 'India' },
      time: '6h ago',
    },
  ];

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'critical': return 'bg-red-500/10 text-red-500 border-red-500/20';
      case 'high': return 'bg-orange-500/10 text-orange-500 border-orange-500/20';
      default: return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
    }
  };

  const suggestedConnections = [
    {
      name: 'Maria Santos',
      profession: 'Investment Director',
      location: 'Lisbon, Portugal',
      image: 'https://images.unsplash.com/photo-1762341114803-a797c44649f0?w=400',
      mutualConnections: 12,
    },
    {
      name: 'David Chen',
      profession: 'Tech Entrepreneur',
      location: 'Singapore',
      image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=400',
      mutualConnections: 8,
    },
    {
      name: 'Sophie Martin',
      profession: 'Legal Counsel',
      location: 'Paris, France',
      image: 'https://images.unsplash.com/photo-1650784854945-264d5b0b6b07?w=400',
      mutualConnections: 15,
    },
  ];

  const recentActivity = [
    {
      user: 'Alexandre Silva',
      action: 'joined the network',
      time: '2 hours ago',
      location: 'São Paulo',
    },
    {
      user: 'Emma Johnson',
      action: 'updated their profile',
      time: '5 hours ago',
      location: 'London',
    },
    {
      user: 'Carlos Mendez',
      action: 'shared an article',
      time: '1 day ago',
      location: 'Madrid',
    },
  ];

  const stats = [
    { label: t('nav.connections'), value: '247', icon: Users, trend: '+12' },
    { label: 'Profile Views', value: '1.2K', icon: TrendingUp, trend: '+23%' },
    { label: t('nav.messages'), value: '18', icon: MessageSquare, trend: '3 new' },
  ];

  return (
    <div className="min-h-screen bg-background pb-20 md:pb-0">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Header */}
        <div className="mb-8">
          <h1 className="text-4xl mb-2">{t('dashboard.welcome')}, John</h1>
          <p className="text-muted-foreground">
            Here's what's happening in your network today
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
                      <p className="text-3xl font-bold">{stat.value}</p>
                      <p className="text-sm text-accent mt-1">{stat.trend}</p>
                    </div>
                    <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center">
                      <Icon className="w-6 h-6 text-accent" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Urgent Help Requests */}
        {urgentHelpRequests.length > 0 && (
          <Card className="mb-8 border-accent/30 bg-gradient-to-r from-accent/5 to-transparent">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
                    <HeartHandshake className="w-5 h-5 text-accent" />
                  </div>
                  <div>
                    <CardTitle>Urgent Help Requests</CardTitle>
                    <p className="text-sm text-muted-foreground">Members who need immediate assistance</p>
                  </div>
                </div>
                <Link to="/help-requests">
                  <Button variant="accent" size="sm">
                    View All
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {urgentHelpRequests.map((request) => (
                  <div
                    key={request.id}
                    className="p-4 rounded-lg bg-card border border-border hover:border-accent/50 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-medium">{request.title}</h4>
                          <Badge className={cn('border text-xs', getUrgencyColor(request.urgency))}>
                            {request.urgency.toUpperCase()}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1.5">
                            <MapPin className="w-4 h-4" />
                            {request.location.city}, {request.location.country}
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Clock className="w-4 h-4" />
                            {request.time}
                          </div>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" className="flex-shrink-0">
                        Offer Help
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content - 2 columns */}
          <div className="lg:col-span-2 space-y-8">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>{t('dashboard.quickActions')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <Link to="/members" className="group">
                    <div className="p-6 rounded-lg border border-border hover:border-accent hover:bg-accent/5 transition-all text-center">
                      <Users className="w-8 h-8 mx-auto mb-2 text-muted-foreground group-hover:text-accent transition-colors" />
                      <p className="text-sm font-medium">{t('dashboard.findMembers')}</p>
                    </div>
                  </Link>
                  <Link to="/map" className="group">
                    <div className="p-6 rounded-lg border border-border hover:border-accent hover:bg-accent/5 transition-all text-center">
                      <Map className="w-8 h-8 mx-auto mb-2 text-muted-foreground group-hover:text-accent transition-colors" />
                      <p className="text-sm font-medium">{t('dashboard.viewMap')}</p>
                    </div>
                  </Link>
                  <Link to="/messages" className="group">
                    <div className="p-6 rounded-lg border border-border hover:border-accent hover:bg-accent/5 transition-all text-center">
                      <MessageSquare className="w-8 h-8 mx-auto mb-2 text-muted-foreground group-hover:text-accent transition-colors" />
                      <p className="text-sm font-medium">{t('dashboard.sendMessage')}</p>
                    </div>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>{t('dashboard.feed')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="flex items-start gap-4 pb-4 border-b border-border last:border-0 last:pb-0">
                      <Avatar size="md" fallback={activity.user} />
                      <div className="flex-1">
                        <p className="text-sm">
                          <span className="font-medium">{activity.user}</span>{' '}
                          <span className="text-muted-foreground">{activity.action}</span>
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs text-muted-foreground">{activity.time}</span>
                          <span className="text-xs text-muted-foreground">•</span>
                          <span className="text-xs text-accent">{activity.location}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - 1 column */}
          <div className="space-y-8">
            {/* Suggested Connections */}
            <Card>
              <CardHeader>
                <CardTitle>{t('dashboard.suggested')}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {suggestedConnections.map((person, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-start gap-3">
                        <Avatar src={person.image} alt={person.name} size="lg" />
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{person.name}</h4>
                          <p className="text-xs text-muted-foreground">{person.profession}</p>
                          <p className="text-xs text-accent">{person.location}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {person.mutualConnections} mutual connections
                          </p>
                        </div>
                      </div>
                      <Button variant="accent" size="sm" className="w-full gap-2">
                        <UserPlus className="w-4 h-4" />
                        {t('common.connect')}
                      </Button>
                      {index < suggestedConnections.length - 1 && (
                        <div className="border-b border-border pt-2" />
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Map Widget */}
            <Card>
              <CardHeader>
                <CardTitle>Global Network</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="aspect-square bg-muted rounded-lg flex items-center justify-center mb-4">
                  <div className="text-center">
                    <Map className="w-12 h-12 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">View network map</p>
                  </div>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Active Members</span>
                    <span className="font-medium">50,234</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Countries</span>
                    <span className="font-medium">152</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Online Now</span>
                    <span className="font-medium text-green-500">2,847</span>
                  </div>
                </div>
                <Link to="/map">
                  <Button variant="outline" className="w-full mt-4">
                    View Full Map
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <MobileNav />
    </div>
  );
}