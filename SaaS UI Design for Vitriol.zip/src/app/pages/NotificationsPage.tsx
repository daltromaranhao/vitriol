import React from 'react';
import { useTranslation } from 'react-i18next';
import { UserPlus, MessageSquare, ShieldCheck, TrendingUp, Clock } from 'lucide-react';
import { Card, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Avatar } from '../components/ui/Avatar';
import { Badge } from '../components/ui/Badge';
import { Navbar } from '../components/Navbar';
import { MobileNav } from '../components/MobileNav';

export default function NotificationsPage() {
  const { t } = useTranslation();

  const notifications = [
    {
      id: 1,
      type: 'connection',
      icon: UserPlus,
      title: 'New Connection Request',
      message: 'Alex Rivera wants to connect with you',
      time: '5 minutes ago',
      unread: true,
      image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=200',
    },
    {
      id: 2,
      type: 'message',
      icon: MessageSquare,
      title: 'New Message',
      message: 'Maria Santos sent you a message',
      time: '1 hour ago',
      unread: true,
      image: 'https://images.unsplash.com/photo-1762341114803-a797c44649f0?w=200',
    },
    {
      id: 3,
      type: 'verification',
      icon: ShieldCheck,
      title: 'Profile Verified',
      message: 'Your profile has been successfully verified',
      time: '3 hours ago',
      unread: false,
    },
    {
      id: 4,
      type: 'activity',
      icon: TrendingUp,
      title: 'Profile Views',
      message: 'Your profile received 47 new views this week',
      time: '1 day ago',
      unread: false,
    },
    {
      id: 5,
      type: 'connection',
      icon: UserPlus,
      title: 'Connection Accepted',
      message: 'David Chen accepted your connection request',
      time: '2 days ago',
      unread: false,
      image: 'https://images.unsplash.com/photo-1655249481446-25d575f1c054?w=200',
    },
    {
      id: 6,
      type: 'message',
      icon: MessageSquare,
      title: 'New Message',
      message: 'Sophie Martin replied to your message',
      time: '2 days ago',
      unread: false,
      image: 'https://images.unsplash.com/photo-1650784854945-264d5b0b6b07?w=200',
    },
  ];

  const getIconColor = (type: string) => {
    switch (type) {
      case 'connection':
        return 'text-blue-500';
      case 'message':
        return 'text-green-500';
      case 'verification':
        return 'text-accent';
      case 'activity':
        return 'text-purple-500';
      default:
        return 'text-muted-foreground';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <MobileNav />
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl mb-2">{t('nav.notifications')}</h1>
            <p className="text-muted-foreground">
              Stay updated with your network activity
            </p>
          </div>
          <Button variant="outline" size="sm">
            Mark all as read
          </Button>
        </div>

        {/* Notifications List */}
        <div className="space-y-3">
          {notifications.map((notification) => {
            const Icon = notification.icon;
            return (
              <Card
                key={notification.id}
                className={`hover:shadow-md transition-all cursor-pointer ${
                  notification.unread ? 'border-accent/30 bg-accent/5' : ''
                }`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    {/* Icon or Avatar */}
                    {notification.image ? (
                      <Avatar src={notification.image} alt="" size="md" />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                        <Icon className={`w-5 h-5 ${getIconColor(notification.type)}`} />
                      </div>
                    )}

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h3 className="font-medium text-sm">{notification.title}</h3>
                        {notification.unread && (
                          <Badge variant="accent" className="flex-shrink-0">New</Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        {notification.message}
                      </p>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Clock className="w-3 h-3" />
                        {notification.time}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    {notification.type === 'connection' && notification.unread && (
                      <div className="flex gap-2 flex-shrink-0">
                        <Button variant="accent" size="sm">
                          Accept
                        </Button>
                        <Button variant="ghost" size="sm">
                          Decline
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Load More */}
        <div className="text-center mt-8">
          <Button variant="outline">
            Load More Notifications
          </Button>
        </div>
      </main>
    </div>
  );
}