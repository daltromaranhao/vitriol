import React from 'react';
import { Link, useLocation } from 'react-router';
import { useTranslation } from 'react-i18next';
import {
  Home,
  Users,
  Map,
  MessageSquare,
  Bell,
  Settings,
  UserCircle,
  Globe,
  Moon,
  Sun,
  Link2,
  HeartHandshake,
} from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { Button } from './ui/Button';
import { cn } from '../utils/cn';
import { VitriolLogo } from './VitriolLogo';

interface NavbarProps {
  showFull?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({ showFull = true }) => {
  const { t, i18n } = useTranslation();
  const { theme, toggleTheme } = useTheme();
  const location = useLocation();

  const languages = [
    { code: 'en', label: 'English', flag: '🇬🇧' },
    { code: 'pt', label: 'Português', flag: '🇧🇷' },
    { code: 'es', label: 'Español', flag: '🇪🇸' },
    { code: 'fr', label: 'Français', flag: '🇫🇷' },
  ];

  const navItems = [
    { path: '/dashboard', icon: Home, label: t('nav.home') },
    { path: '/help-requests', icon: HeartHandshake, label: t('nav.helpRequests') },
    { path: '/members', icon: Users, label: t('nav.members') },
    { path: '/map', icon: Map, label: t('nav.map') },
    { path: '/messages', icon: MessageSquare, label: t('nav.messages') },
    { path: '/connections', icon: Link2, label: t('nav.connections') },
  ];

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
    localStorage.setItem('language', lng);
  };

  return (
    <nav className="sticky top-0 z-50 bg-card border-b border-border/50 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3">
            <VitriolLogo size={40} className="text-accent" />
            <div className="flex flex-col">
              <span className="text-lg font-semibold tracking-tight">Vitriol</span>
              <span className="text-xs text-muted-foreground">{t('landing.hero.subtitle')}</span>
            </div>
          </Link>

          {/* Center Navigation */}
          {showFull && (
            <div className="hidden md:flex items-center gap-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Link key={item.path} to={item.path}>
                    <Button
                      variant="ghost"
                      size="sm"
                      className={cn(
                        'gap-2',
                        isActive && 'bg-accent/20 text-accent'
                      )}
                    >
                      <Icon className="w-4 h-4" />
                      {item.label}
                    </Button>
                  </Link>
                );
              })}
            </div>
          )}

          {/* Right Side Actions */}
          <div className="flex items-center gap-2">
            {/* Language Selector */}
            <div className="relative group">
              <Button variant="ghost" size="icon">
                <Globe className="w-5 h-5" />
              </Button>
              <div className="absolute right-0 mt-2 w-48 bg-card border border-border rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => changeLanguage(lang.code)}
                    className={cn(
                      'w-full flex items-center gap-3 px-4 py-2 text-sm hover:bg-accent/10 first:rounded-t-lg last:rounded-b-lg transition-colors',
                      i18n.language === lang.code && 'bg-accent/20 text-accent'
                    )}
                  >
                    <span>{lang.flag}</span>
                    <span>{lang.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Theme Toggle */}
            <Button variant="ghost" size="icon" onClick={toggleTheme}>
              {theme === 'dark' ? (
                <Sun className="w-5 h-5" />
              ) : (
                <Moon className="w-5 h-5" />
              )}
            </Button>

            {showFull && (
              <>
                {/* Notifications */}
                <Link to="/notifications">
                  <Button variant="ghost" size="icon" className="relative">
                    <Bell className="w-5 h-5" />
                    <span className="absolute top-1 right-1 w-2 h-2 bg-accent rounded-full" />
                  </Button>
                </Link>

                {/* Profile */}
                <Link to="/profile">
                  <Button variant="ghost" size="icon">
                    <UserCircle className="w-5 h-5" />
                  </Button>
                </Link>

                {/* Settings */}
                <Link to="/settings">
                  <Button variant="ghost" size="icon">
                    <Settings className="w-5 h-5" />
                  </Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};