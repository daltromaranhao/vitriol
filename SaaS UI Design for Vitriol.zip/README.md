# Vitriol — Global Brotherhood

A premium, production-ready global networking platform designed to connect verified professionals worldwide.

## 🌟 Overview

**Vitriol** is an exclusive private network that enables trusted connections, professional networking, and meaningful relationships across borders. Built with modern web technologies and designed for a global audience.

## ✨ Key Features

### 🌍 **Multilingual Support (i18n)**
- **4 Languages**: English, Portuguese, Spanish, French
- Language selector in navbar and onboarding
- Proper text expansion handling (30% tolerance)
- Persistent language preference
- Real-time language switching

### 🎨 **Dual Theme System**

#### **Theme 1: Premium Dark (Primary)**
- Deep Navy Blue (#0B1F3A) primary
- Gold (#C6A85A) accent
- Charcoal Black (#0A0A0A) background
- Sophisticated, exclusive, high-end feel

#### **Theme 2: Clean Light (Secondary)**
- Royal Blue (#2563EB) primary
- Light Blue (#EAF2FF) secondary
- White (#FFFFFF) background
- Modern, clean, professional feel

**Features:**
- One-click theme toggle
- System preference detection
- Persistent theme selection
- Smooth transitions
- Full component compatibility

### 📱 **Fully Responsive**
- Mobile-first design approach
- Adaptive layouts for all screen sizes
- Mobile bottom navigation
- Touch-optimized interactions
- Responsive typography and spacing

### 🔐 **Core Functionality**

#### **Authentication & Onboarding**
- Social login (Google, Apple)
- Email/password authentication
- Multi-step onboarding flow with progress indicator
- Profile setup with photo upload
- Interest selection

#### **User Dashboard**
- Activity feed
- Suggested connections
- Quick actions
- Network statistics
- Real-time updates

#### **Member Directory**
- Advanced search and filters
- Member cards with verification badges
- Interest tags
- Location information
- Connect/view profile actions

#### **Global Network Map**
- Interactive world map
- Member clusters by location
- Country and city statistics
- Real-time member counts
- Geographic filtering

#### **Private Messaging**
- Real-time conversations
- Online/offline indicators
- Message threading
- Search functionality
- Voice and video call integration

#### **Connections System**
- My connections
- Connection requests (accept/decline)
- Suggested connections based on mutual connections
- Connection management

#### **Community Feed**
- Post composer
- Activity feed
- Likes, comments, shares
- Member updates
- Content discovery

#### **Verification System**
- Verified member badges
- Identity verification status
- Trust indicators
- Professional credentials

#### **Notifications Center**
- Connection requests
- Messages
- Profile activity
- System notifications
- Real-time updates

#### **Settings & Privacy**
- Profile management
- Language preference
- Theme selection
- Privacy controls
- Security settings
- Notification preferences

## 🏗️ Technical Architecture

### **Frontend Stack**
- **React 18** - UI library
- **React Router 7** - Client-side routing
- **TypeScript** - Type safety
- **Tailwind CSS v4** - Styling system
- **i18next** - Internationalization
- **Lucide React** - Icon system

### **Design System**
- Custom theme tokens (CSS variables)
- Reusable UI components
- Consistent spacing and typography
- Accessible color contrasts
- Professional shadows and gradients

### **Component Library**
- Button (multiple variants and sizes)
- Card (header, content, footer)
- Input (themed, accessible)
- Avatar (with online status)
- Badge (multiple variants)
- Navbar (responsive)
- Mobile Navigation

### **Typography**
- **Headings**: Cinzel (elegant serif)
- **Body/UI**: Inter (clean sans-serif)
- Responsive font scaling
- Optimized line heights

## 📂 Project Structure

```
src/
├── app/
│   ├── components/
│   │   ├── ui/          # Reusable UI components
│   │   │   ├── Button.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── Avatar.tsx
│   │   │   └── Badge.tsx
│   │   ├── Navbar.tsx   # Main navigation
│   │   └── MobileNav.tsx # Mobile bottom nav
│   ├── contexts/
│   │   └── ThemeContext.tsx  # Theme provider
│   ├── pages/
│   │   ├── LandingPage.tsx
│   │   ├── SignInPage.tsx
│   │   ├── SignUpPage.tsx
│   │   ├── OnboardingPage.tsx
│   │   ├── DashboardPage.tsx
│   │   ├── ProfilePage.tsx
│   │   ├── MembersDirectoryPage.tsx
│   │   ├── ConnectionsPage.tsx
│   │   ├── MessagesPage.tsx
│   │   ├── MapPage.tsx
│   │   ├── FeedPage.tsx
│   │   ├── NotificationsPage.tsx
│   │   └── SettingsPage.tsx
│   ├── utils/
│   │   └── cn.ts        # Class name utility
│   ├── i18n.ts          # i18n configuration
│   ├── routes.ts        # Route definitions
│   └── App.tsx          # Root component
└── styles/
    ├── theme.css        # Theme tokens
    └── fonts.css        # Font imports
```

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- npm or pnpm

### Installation

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

### Usage

1. **Landing Page** - Start at `/` to see the public landing page
2. **Sign Up** - Create an account at `/auth/signup`
3. **Onboarding** - Complete your profile at `/onboarding`
4. **Dashboard** - Access your personalized dashboard at `/dashboard`
5. **Explore** - Navigate through members, map, messages, and more

## 🎯 Design Principles

### **Elegance**
- Refined typography with Cinzel headings
- Subtle animations and transitions
- Premium color palette with gold accents

### **Global**
- Multi-language support from day one
- International date/time formats
- Cultural sensitivity in design

### **Fraternal**
- Trust-based community feel
- Verification badges
- Professional networking focus

### **Premium but Welcoming**
- Sophisticated dark theme as primary
- Clean, accessible light theme
- Polished UI without intimidation

### **Minimalist Luxury**
- Clean layouts with purposeful spacing
- Elegant shadows and borders
- Quality over quantity in features

## 🌐 Internationalization

The platform supports 4 languages with comprehensive translations:

- **English** (en) - Default
- **Portuguese** (pt) - Full translation
- **Spanish** (es) - Full translation
- **French** (fr) - Full translation

All UI text, labels, and messages are fully localized. Language selection is available in:
- Navbar (persistent across all pages)
- Onboarding flow
- Settings page

## 🎨 Theme Customization

Themes are built with CSS custom properties for easy customization:

```css
/* Premium Dark Theme */
--primary: #0B1F3A;
--accent: #C6A85A;
--background: #0A0A0A;

/* Clean Light Theme */
--primary: #2563EB;
--accent: #D6BA6A;
--background: #FFFFFF;
```

Change themes:
1. Use the theme toggle in the navbar
2. Access theme settings in Settings page
3. System will remember your preference

## 📱 Mobile Experience

The platform is fully optimized for mobile devices:

- **Responsive Grid System**: Adapts from 1-4 columns based on screen size
- **Mobile Navigation**: Bottom tab bar on mobile devices
- **Touch Targets**: Minimum 44px for all interactive elements
- **Optimized Images**: Responsive image loading
- **Adaptive Typography**: Scales appropriately on small screens

## 🔒 Privacy & Security

- Private network model
- Verified member system
- Granular privacy controls
- Secure authentication
- Data confidentiality
- Professional networking focus

## 🎓 Best Practices

### **Accessibility**
- Semantic HTML
- ARIA labels where needed
- Keyboard navigation support
- Color contrast ratios (WCAG AA)
- Focus indicators

### **Performance**
- Code splitting with React Router
- Optimized images
- CSS-in-JS with Tailwind
- Minimal bundle size
- Fast page transitions

### **UX**
- Clear call-to-actions
- Consistent navigation
- Loading states
- Error handling
- User feedback

## 📄 License

This is a demonstration project created for Figma Make.

## 🙏 Credits

- **Design System**: Custom built with Tailwind CSS v4
- **Icons**: Lucide React
- **Images**: Unsplash
- **Fonts**: Google Fonts (Cinzel, Inter)
- **i18n**: react-i18next

---

**Vitriol** — Connecting professionals, building trust, creating opportunities worldwide. 🌍
